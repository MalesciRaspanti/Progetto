//
// Created by francesco on 06/06/18.
//

#ifndef PROJECT_ENTITY_H
#define PROJECT_ENTITY_H

#include "SFML/Graphics.hpp"
#include <SFML/Graphics/Drawable.hpp>
#include <SFML/Graphics/Transformable.hpp>

#include <iostream>

using namespace std;

class entity {
public:
    sf::RectangleShape rect;
    sf::Sprite sprite;
    sf::Text text;
};


#endif //PROJECT_ENTITY_H

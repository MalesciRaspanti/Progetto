//
// Created by francesco on 06/06/18.
//

#ifndef PROJECT_PLAYER_H
#define PROJECT_PLAYER_H

#include "SFML/Graphics.hpp"
#include <SFML/Graphics/Drawable.hpp>
#include <SFML/Graphics/Transformable.hpp>

#include "Item.h"
#include "entity.h"

class player : public entity {
public:

    explicit player(int hp, int mS, int mHp) : hp(hp), movementSpeed(mS), maxhp(mHp) {
        rect.setSize(sf::Vector2f(32, 32));
        rect.setPosition(1400, 800);
        rect.setFillColor(sf::Color::Transparent);
        sprite.setTextureRect(sf::IntRect(0, 0, 32, 32));
    };

    virtual ~player();

    int count = 0;
    int movementSpeed; //8
    int attackDamage = 5;
    float attackSpeed = 0.4;
    int counterWalking = 0;
    bool powerup = false;
    bool PickaxePower = false;
    int direction = 0; // 1 - up, 2 - down, 3 - left, 4 - right
    bool canMoveUp = true;
    bool canMoveDown = true;
    bool canMoveLeft = true;
    bool canMoveRight = true;
    int hp; //10
    int maxhp=10;
    int gil = 100;
    bool alive = true;

    bool setAlive(bool a){
        player::alive = a;
    }
    int getAlive(){
        return alive;
    }

    void update();
    void updateMovement();

};


#endif //PROJECT_PLAYER_H

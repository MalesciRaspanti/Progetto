//
// Created by francesco on 06/06/18.
//

#ifndef PROJECT_ENEMY_H
#define PROJECT_ENEMY_H


#include "entity.h"
#include "Random.h"

class enemy: public entity
{
public:
    explicit enemy(int hp, int mS, int mHp, int aD) : hp(hp), movementSpeed(mS), maxhp(mHp), attackDamage(aD) {
        rect.setSize(sf::Vector2f(32, 32));
        rect.setPosition(400, 200);
        rect.setFillColor(sf::Color::Transparent);
        sprite.setTextureRect(sf::IntRect(0, 0, 32, 32));
    };

    virtual ~enemy();

    int count = 0;
    int counter=0;
    int movementSpeed; //8
    int attackDamage; //5
    int counterWalking = 0;
    int movementLength = 100;
    int direction = 0; // 1 - up, 2 - down, 3 - left, 4 - right
    int hp; //10
    int maxhp; //10
    int spritex = 32;
    int spritey = 32;
    bool alive = true;
    bool canMoveUp = true;
    bool canMoveDown = true;
    bool canMoveLeft = true;
    bool canMoveRight = true;
    int spritexStart = 32 * 0;
    int spriteyStart = 32 * 0;
    bool aggroed = false;



    void update();
    void isGuard(int counter, int counter2, float x, float y);
    void isPrisoner(int counter, int counter2, float x, float y);
    void updateMovement();
};


#endif //PROJECT_ENEMY_H

#include <iostream>
#include <SFML/Graphics/RenderWindow.hpp>
#include "SFML/Graphics.hpp"
#include <SFML/Graphics/Drawable.hpp>
#include <SFML/Graphics/Transformable.hpp>

#include "player.h"
#include "entity.h"
#include "enemy.h"
#include "wall.h"
#include "inventory.h"
#include "Projectile.h"
#include "Pickup.h"
#include "Menu.h"

using namespace std;

int main(int argc, char **argv) {

   
    //Create Player
    class player Player1(10, 8, 10);
    sf::Texture texturePlayer;
    if(!texturePlayer.loadFromFile("prigioniero.png"))
        std::cout << "Error could not load player image" << std::endl;
    Player1.sprite.setTexture(texturePlayer);

    // Create a graphical text to display
    sf::Font font;
    if (!font.loadFromFile("arial.ttf"))
    {
        // handle error
    }

   
    // Enemy Vector Array
    vector<enemy>::const_iterator iter4;
    vector<enemy> enemyArray;

    sf::Texture textureEnemy;
    if (!textureEnemy.loadFromFile("Guard.png")) {
        std::cout << "Error could not load player image" << std::endl;
    }

    sf::Texture textureEnemyPrisoner;
    if (!textureEnemyPrisoner.loadFromFile("SpritePris.png")) {
        std::cout << "Error could not load player image" << std::endl;
    }

   
    // Enemy Object
    class enemy enemy1(10, 8, 10, 5);

    //enemy1.sprite.setTextureRect(sf::IntRect(0, 0, 32, 32));

   

    //Create main game window
    sf::RenderWindow window(sf::VideoMode(1600,900),"Gioco");


    // View
    sf::View view1(sf::FloatRect(200, 200, 300, 200));
    view1.setSize(sf::Vector2f(window.getSize().x, window.getSize().y));
    view1.setCenter(sf::Vector2f(view1.getSize().x/2, view1.getSize().y/2));
    window.setView(view1);

    if(chooseMenu==1){
        // Start the game loop
        while (window.isOpen())
        {
            // Process events
            sf::Event event;
            while (window.pollEvent(event))
            {
                // Close window: exit
                if (event.type == sf::Event::Closed) {
                    window.close();
                }

                // Escape pressed: exit
                if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape) {
                    window.close();
                }
            }

            // Clear screen
            window.clear();


            // Draw Enemies
            counter = 0;
            for (iter4 = enemyArray.begin(); iter4 != enemyArray.end(); iter4++)
            {
                enemyArray[counter].update();
                enemyArray[counter].updateMovement();
                //window.draw(enemyArray[counter].rect);
                window.draw(enemyArray[counter].sprite);

                counter++;
            }

           

            // Update Player
            Player1.update();
            Player1.updateMovement();

            
            // Player View
            window.setView(view1);
            view1.setCenter(Player1.rect.getPosition());

            // Draw Player
            window.draw(Player1.sprite);
            //window.draw(Player1.rect);

            

            // Update the window
            window.display();
        }


            return true;
        }
}















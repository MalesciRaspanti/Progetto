//
// Created by francesco on 06/06/18.
//

#include "enemy.h"


enemy::~enemy() = default;

void enemy::update()
{
    sprite.setPosition(rect.getPosition());
}


void enemy::updateMovement()
{

    if (direction == 1) // Up
    {

        if (canMoveUp == true)
        {

            rect.move(0,-movementSpeed);
            sprite.setTextureRect(sf::IntRect(counterWalking * 32, 32 * 3, 32, 32));
            canMoveUp = true;
            canMoveDown = true;
            canMoveLeft = true;
            canMoveRight = true;
        }
    }
    else if (direction == 2) // Down
    {
        if (canMoveDown == true)
        {
            rect.move(0,movementSpeed);
            sprite.setTextureRect(sf::IntRect(counterWalking * 32, 0, 32, 32));
            canMoveUp = true;
            canMoveDown = true;
            canMoveLeft = true;
            canMoveRight = true;
        }
    }
    else if (direction == 3) // Left
    {
        if (canMoveLeft == true)
        {
            rect.move(-movementSpeed,0);
            sprite.setTextureRect(sf::IntRect(counterWalking * 32, 32 * 1, 32, 32));
            canMoveUp = true;
            canMoveDown = true;
            canMoveLeft = true;
            canMoveRight = true;
        }
    }
    else if (direction == 4) // Right
    {
        if (canMoveRight == true)
        {
            rect.move(movementSpeed,0);
            sprite.setTextureRect(sf::IntRect(counterWalking * 32, 32 * 2, 32, 32));
            canMoveUp = true;
            canMoveDown = true;
            canMoveLeft = true;
            canMoveRight = true;
        }
    }
    else
    {
        // No movement
    }

    if (count % 3 == 0)
        counterWalking++;
    if (counterWalking == 2)
    {
        counterWalking = 0;
    }

    counter++;

    if (aggroed != true)
    {
        counter++;
        if (counter >= movementLength)
        {
            direction = generateRandom(10);
            counter = 0;
        }
    }

}


void enemy::isGuard(int counter, int counter2, float x, float y) {
    hp = 10;
    maxhp = 10;
    spritexStart = 50 * 32;
    spriteyStart= 35 * 32;
    rect.setPosition((counter * 32)+ 32+ x+850, y+ 150);
}

void enemy::isPrisoner(int counter, int counter2, float x, float y) {
    hp = 10;
    maxhp = 10;
    spritexStart = 50 * 32;
    spriteyStart= 35 * 32;
    rect.setPosition((counter * 32)+ 32+ x+850, y+ 350);
}